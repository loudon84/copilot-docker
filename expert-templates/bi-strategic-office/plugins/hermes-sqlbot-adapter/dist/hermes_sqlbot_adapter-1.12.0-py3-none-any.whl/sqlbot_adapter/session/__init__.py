"""Session store package."""
