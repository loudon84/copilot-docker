"""Result normalizer package."""
