"""SQLBot MCP client package."""
